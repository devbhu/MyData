package com.test.constructor;

public class Main {
	
	public static void main(String[] args) {
		SubClass subCls = new SubClass();
		System.out.println("main "+subCls);
		//SuperClass supCls = new SubClass();
		
		int k=65;
		char a = (char) k;
		
		System.out.println(a);
		
		
		
		
	}

}
