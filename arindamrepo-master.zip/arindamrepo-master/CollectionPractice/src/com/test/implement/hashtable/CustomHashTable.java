package com.test.implement.hashtable;

import java.util.Map;

public class CustomHashTable {
	
	
	private static class Entry<K,V> implements Map.Entry<K, V>{

		@Override
		public K getKey() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public V getValue() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public V setValue(V value) {
			// TODO Auto-generated method stub
			return null;
		}}
          
	
	    
	
}
