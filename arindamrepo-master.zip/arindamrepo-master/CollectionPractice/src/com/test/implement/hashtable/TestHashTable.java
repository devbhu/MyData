package com.test.implement.hashtable;

import java.util.Hashtable;
import java.util.Map;

public class TestHashTable {

	public static void main(String[] args) {
		
	  
		
		
		
	
		
		
	}
}
