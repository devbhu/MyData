package com.test.collection.hashmap;

public class TestHashMap {
	
	public static void main(String[] args) {
		
		int hash = 20;
		
		int size = 20;
		
	  System.out.println(new int[Integer.MAX_VALUE]);
		
		
		
	}

}
