package test.cyclicbarrier.impl;

public interface DiceGame {
	
	public static final int numberOfPersons = 5;
	public void startGame();
	
}
