package test.sort.hashmap;

public class EntryKeyValue {
	
	private Integer key;
	private Integer value;
	
	public Integer getKey() {
		return key;
	}

	public Integer getValue() {
		return value;
	}

	public EntryKeyValue(Integer key, Integer value) {
		this.key = key;
		this.value = value;
	}

}
