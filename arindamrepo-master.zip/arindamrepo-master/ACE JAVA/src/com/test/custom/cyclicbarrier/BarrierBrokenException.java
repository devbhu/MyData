package com.test.custom.cyclicbarrier;

public class BarrierBrokenException extends RuntimeException {

}
