package com.test.file.sorting;

public class Task implements Runnable{

	int fileId;
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
