package com.basic.ormaping;

public class BasicOrMapping {

	private Integer id;

	private String memeberGuide;

	

}
