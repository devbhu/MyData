package com.test.tableperclass;

public class TestProxy {

}
