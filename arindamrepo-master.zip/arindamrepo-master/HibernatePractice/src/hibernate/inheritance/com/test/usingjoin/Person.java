/**
 * 
 */
package com.test.usingjoin;

/**
 * @author ASanyal
 *
 */
public class Person {
	
	Integer personId;
	
	String personName;
	
	String personCity;
	String personState;
	String personCountry;
	
	Integer personVersion;

	/**
	 * @return the personVersion
	 */
	public Integer getPersonVersion() {
		return personVersion;
	}

	/**
	 * @param personVersion the personVersion to set
	 */
	public void setPersonVersion(Integer personVersion) {
		this.personVersion = personVersion;
	}

	/**
	 * @return the personCity
	 */
	public String getPersonCity() {
		return personCity;
	}

	/**
	 * @param personCity the personCity to set
	 */
	public void setPersonCity(String personCity) {
		this.personCity = personCity;
	}

	/**
	 * @return the personState
	 */
	public String getPersonState() {
		return personState;
	}

	/**
	 * @param personState the personState to set
	 */
	public void setPersonState(String personState) {
		this.personState = personState;
	}

	/**
	 * @return the personCountry
	 */
	public String getPersonCountry() {
		return personCountry;
	}

	/**
	 * @param personCountry the personCountry to set
	 */
	public void setPersonCountry(String personCountry) {
		this.personCountry = personCountry;
	}

	/**
	 * @return the personId
	 */
	public Integer getPersonId() {
		return personId;
	}

	/**
	 * @param personId the personId to set
	 */
	public void setPersonId(Integer personId) {
		this.personId = personId;
	}

	/**
	 * @return the personName
	 */
	public String getPersonName() {
		return personName;
	}

	/**
	 * @param personName the personName to set
	 */
	public void setPersonName(String personName) {
		this.personName = personName;
	}

}
