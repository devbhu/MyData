package com.test.tableperclass;


public class ChequePayment extends Payment{

private  Integer paymentDetailsId;
	

}
