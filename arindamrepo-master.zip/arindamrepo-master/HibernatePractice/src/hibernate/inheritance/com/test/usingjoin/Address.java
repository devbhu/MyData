/**
 * 
 */
package com.test.usingjoin;

/**
 * @author ASanyal
 *
 */
public class Address {

	String personCity;
	String personState;
	String personCountry;

	/**
	 * @return the personCity
	 */
	public String getPersonCity() {
		return personCity;
	}

	/**
	 * @param personCity
	 *            the personCity to set
	 */
	public void setPersonCity(String personCity) {
		this.personCity = personCity;
	}

	/**
	 * @return the personState
	 */
	public String getPersonState() {
		return personState;
	}

	/**
	 * @param personState
	 *            the personState to set
	 */
	public void setPersonState(String personState) {
		this.personState = personState;
	}

	/**
	 * @return the personCountry
	 */
	public String getPersonCountry() {
		return personCountry;
	}

	/**
	 * @param personCountry
	 *            the personCountry to set
	 */
	public void setPersonCountry(String personCountry) {
		this.personCountry = personCountry;
	}

}
