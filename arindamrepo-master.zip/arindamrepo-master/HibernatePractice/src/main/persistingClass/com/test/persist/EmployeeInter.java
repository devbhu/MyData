package com.test.persist;

public interface EmployeeInter {
	public String getJobID() ;
	
	/**
	 * @param jobID
	 *            the jobID to set
	 */
	public void setJobID(String jobID) ;
}
