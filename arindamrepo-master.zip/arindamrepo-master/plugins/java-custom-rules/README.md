This example demonstrates how to write new rules for Java analyzer.

It requires to install the Java plugin, at least version 3.1, which is compatible with SonarQube 4.5.x LTS.
