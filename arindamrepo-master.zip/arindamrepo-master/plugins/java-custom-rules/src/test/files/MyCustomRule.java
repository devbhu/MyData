class A {

  int foo() {}
  int foo(int a) {}
  int foo(int a, int b) {}

  Object foo(Object a){}
  String foo(String a){}
  String foo(Object a){}
}