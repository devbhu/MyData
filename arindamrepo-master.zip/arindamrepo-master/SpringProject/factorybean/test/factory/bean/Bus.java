package test.factory.bean;

public class Bus implements Vehicle{

	

}
