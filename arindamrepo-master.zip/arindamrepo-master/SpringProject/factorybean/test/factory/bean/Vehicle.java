package test.factory.bean;

public interface Vehicle {

}
