package com.test.autowiring.beans;

import com.test.pojos.Inter;

public class Person1 implements Inter {

	public Person1() {
		System.out.println("Person 1 instantiated !! ");
	}
}
