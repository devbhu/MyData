package com.test.autowiring.beans;

import com.test.pojos.Inter;

public class Person implements Inter{

}
