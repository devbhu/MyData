package com.test.pojos;

public interface Inter {

}
