package com.test.pojos;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class TestBeanPojo1 implements Inter {
	

	
    TestBeanPojo pojo;

	public TestBeanPojo getPojo() {
		return pojo;
	}

	public void setPojo(TestBeanPojo pojo) {
		this.pojo = pojo;
	}
   
}
