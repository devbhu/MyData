package test.custom.qualifier;

public enum GenderType {

  MALE,FEMALE;
}
