/**
 * 
 */
package com.test.convert.editors;

import java.beans.PropertyEditorSupport;

/**
 * @author vickey
 *
 */
public class CustomPropertyEditorConverter extends PropertyEditorSupport{
   
	
   /*  @Override
	public void setAsText(String text){
		
    	setValue(Integer.valueOf(Double.valueOf(text).intValue()));
	
	}*/
	
	
}
