package com.test.validate;

public class CustomerValidator {

}
