package com.test.scope.beans;

public class ScopeBean {

}
