package com.test.java.config;

public class HelloWorld {

	

}
