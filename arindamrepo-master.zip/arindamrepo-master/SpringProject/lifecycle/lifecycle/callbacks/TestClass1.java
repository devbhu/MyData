package lifecycle.callbacks;

public class TestClass1 {

	public void clear(){
		
		System.out.println("Destroy method of Test Class 1 called !!!");
	}

}
